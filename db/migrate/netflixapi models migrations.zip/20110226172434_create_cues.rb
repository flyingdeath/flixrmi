class CreateCues < ActiveRecord::Migration
  def self.up
    create_table :cues do |t|

     # t.timestamps
    end
  end

  def self.down
    drop_table :cues
  end
end
